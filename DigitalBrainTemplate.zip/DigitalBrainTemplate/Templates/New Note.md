---
date: {{date}}
type: 
tags: 
---
#### Parent Document:
[[<link>]]
#### Status Tag:
#🌱
--- 
