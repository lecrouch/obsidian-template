---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: 📥/📜/🟥

type: article
keywords: 

author:
link: 
---
#### Parent Document:  [[<link>]]
---
# Notes
