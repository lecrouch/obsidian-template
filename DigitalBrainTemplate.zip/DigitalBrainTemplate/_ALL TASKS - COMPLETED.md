## Personal
```tasks
done
path includes Personal
sort by done reverse
```

## Work
```tasks
done
path includes Work
sort by done reverse
```

## ALL
```tasks
done
sort by done reverse
```