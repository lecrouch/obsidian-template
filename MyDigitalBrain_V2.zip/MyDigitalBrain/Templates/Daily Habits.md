---
date: <% tp.date.now("YYYY-MM-DD") %>
type: habit
🏋️: ⚪
🚀: ⚪
🎶: ⚪
⚙️: ⚪
👫: ⚪
🤠: ⚪️
---

### **Nailed:**                         🟢
### **Failed:**                          🔴
### **Not Recorded:**           ⚪️

#  HABIT KEY
---
## 🏋️  :  Exercise
## 🚀  :  Space Travel
## 🎶  :  Listen to some sounds
## ⚙️   :  Gears?
## 👫  :  Relationship Fertilizer
## 🤠  :  Act like a cowperson