---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: 📥/🎧/🟥

type: podcast
keywords: 

author:
link: 
---
#### Parent Document:  [[<link>]]
---
# Notes
