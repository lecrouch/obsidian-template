---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: 📥/💭/🟥

type: thought
keywords: 
---

#### Parent Document:  [[<link>]]
---
# Notes
