## Personal
```tasks
not done
path includes Personal
sort by start reverse
sort by priority
```

## Work
```tasks
not done
path includes Work
sort by start reverse
sort by priority
```


## ALL
```tasks
not done
```