---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: 📥/🎥/🟥

type: video
keywords: 

author:
link: 
---
#### Parent Document:  [[<link>]]
---
# Notes
