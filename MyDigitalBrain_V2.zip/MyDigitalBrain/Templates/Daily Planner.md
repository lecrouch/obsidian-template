[[2022 Work Meeting Notes]]

## Day Planner
