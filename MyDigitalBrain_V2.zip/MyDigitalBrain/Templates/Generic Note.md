---
date: <% tp.date.now("YYYY-MM-DD") %>
tags: 📥/💭/🟥

type: thought
keywords: 

author:
link: 
---
#### Parent Document:  [[<link>]]
---
# Notes
