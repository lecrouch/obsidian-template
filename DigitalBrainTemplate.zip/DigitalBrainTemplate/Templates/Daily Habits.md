---
date: {{date}}
type: habit
🏋️: ⚪
🚀: ⚪
🎶: ⚪
⚙️: ⚪
👫: ⚪
🤠: ⚪️
---

### **Nailed:**                         🟢
### **Failed:**                          🔴
### **Not Recorded:**           ⚪️

#  HABIT KEY
---
## 🏋️  :  Exercise
## 🚀  :  Space Travel
## 🎶  :  Listen to some sounds
## ⚙️   :  Gears?
## 👫  :  Relationship Fertilizer
## 🤠  :  Act like a cowperson